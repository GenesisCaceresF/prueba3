from django.apps import AppConfig


class PruebaAplicacionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prueba_aplicacion'
