from django.shortcuts import render
# Create your views here.
from .models import Vehiculo
from .forms import VehiculoFormulario
from django.http import HttpResponseServerError
from django.views.generic import (
    View,
    TemplateView,
    ListView,
    DetailView
    )

def index(request):
    return render(request, 'index.html', {})


def lista_vehiculo(request):
    vehiculos = Vehiculo.objects.all()
    return render(request, 'lista_vehiculo.html', {'vehiculos': vehiculos})


def nuevo_vehiculo(request):
    vehiculo = Vehiculo()
    
    if request.method == 'POST':
        nuevoVehiculo = VehiculoFormulario(request.POST, instance=vehiculo)
        nuevoVehiculo.save()
        return render(request, 'index.html', {})

    else:
        formulario = VehiculoFormulario()
        return render(request, 'nuevo_vehiculo.html', {'formulario': formulario})

class Error404View(TemplateView):
    template_name = 'error.html'


class Error505View(TemplateView):
    template_name = 'error.html'
    @classmethod
    def as_error_view(cls):
        V = cls.as_view()
        def view(request):
            r = V(request)
            r.render()
            return r
        return view

    
