from django.shortcuts import render
# Create your views here.
from .models import Vehiculo
from .forms import VehiculoFormulario

def index(request):
    return render(request, 'index.html', {})


def lista_vehiculo(request):
    vehiculos = Vehiculo.objects.all()
    return render(request, 'lista_vehiculo.html', {'vehiculos': vehiculos})


def nuevo_vehiculo(request):
    vehiculo = Vehiculo()
    
    if request.method == 'POST':
        nuevoVehiculo = VehiculoFormulario(request.POST, instance=vehiculo)
        nuevoVehiculo.save()
        return render(request, 'index.html', {})

    else:
        formulario = VehiculoFormulario()
        return render(request, 'nuevo_vehiculo.html', {'formulario': formulario})
