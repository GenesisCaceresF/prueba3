from django.db import models

# Create your models here.
from django.utils import timezone
from django.core.validators import MaxValueValidator
from django.core.validators import MinValueValidator

 

class Vehiculo(models.Model):
    vin = models.CharField(max_length=17, primary_key=True)
    
    patente = models.CharField(max_length=6)

    anio_fabricacion =  models.PositiveIntegerField(default=1930, validators=[MaxValueValidator(2021), MinValueValidator(1930)])

    fecha_recepcion = models.DateField(
        blank=True, null=True)
    
    marca = models.TextField() 

    modelo = models.TextField()

    def publish(self):
        self.publish_date = timezone.now()
        self.save()

    def _str_(self):
        return self.patente
