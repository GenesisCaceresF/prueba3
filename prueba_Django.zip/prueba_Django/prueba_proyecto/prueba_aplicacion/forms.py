from django import forms
from django.forms import ModelForm
from .models import Vehiculo

class VehiculoFormulario(forms.ModelForm):
    anio_fabricacion = forms.IntegerField(min_value=4, max_value=4)
    class Meta:
        model = Vehiculo
        fields = ('vin', 'patente',  'anio_fabricacion', 'fecha_recepcion', 'marca', 'modelo',)

