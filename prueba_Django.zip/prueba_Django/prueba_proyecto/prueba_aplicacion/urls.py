from django.urls import path, include
from .import views

urlpatterns = [
    path('', views.index),
    path('lista_vehiculo', views.lista_vehiculo),
    path('nuevo_vehiculo', views.nuevo_vehiculo),
]
